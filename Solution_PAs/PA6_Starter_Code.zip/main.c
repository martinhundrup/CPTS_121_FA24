/*
 * File: main.c
 * Author: Martin Hundrup
 * Professor: Andy O'Fallon
 * Class: CPT_S 121, Fall 2024
 * Assignment: PA6 - Battleship
 * Created: October 28, 2024
 * Last Updated: October 28, 2024
 */

#include "PA6.h"

int main() {

	srand((unsigned int)time(NULL));

	printf("PA 6 example solution.\n\n");

	start_application();

	return 0;
}