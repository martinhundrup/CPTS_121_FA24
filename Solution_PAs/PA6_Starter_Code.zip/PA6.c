/*
 * File: PA6.c
 * Author: Martin Hundrup
 * Professor: Andy O'Fallon
 * Class: CPT_S 121, Fall 2024
 * Assignment: PA6 - Battleship
 * Created: October 28, 2024
 * Last Updated: October 28, 2024
 */

#include "PA6.h"

void start_application() {

	// main loop
	while (1) { // use while 'true' for simplicity

		printf("welcome to battleship! please enter one of the following options below:\n");
		printf("\t1. display rules\n");
		printf("\t2. start game\n");
		printf("\t3. exit program\n");

		printf("> ");
		int option = get_int();

		// exit condition
		if (option == 3) return;
		else if (option == 1) {

			print_game_rules();
			system("pause");
		}
		else if (option == 2) play_battleship();


		system("cls");
	}
}

void play_battleship() {



}

void print_game_rules() {

	printf("these are the rules of battleship:\n");
}

#pragma region Utility

int get_int() {

	int input = 0;
	scanf("%d", &input);
	getchar(); // clear the newline char
	return input;
}

char get_char() {

	char input = 0;
	scanf("%c", &input);
	getchar(); // clear the newline char
	return input;
}

#pragma endregion
