/*
 * File: PA6.h
 * Author: Martin Hundrup
 * Professor: Andy O'Fallon
 * Class: CPT_S 121, Fall 2024
 * Assignment: PA6 - Battleship
 * Created: October 28, 2024
 * Last Updated: October 28, 2024
 */

#ifndef PA6
#define PA6

#define _CRT_SECURE_NO_WARNINGS

#define HIT '*' // the symbol to display for a hit ship
#define MISS 'm' // the symbol to display for a missed shot
#define SIZE 10 // the amount of columns and rows in the game board

#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <ctype.h>	// isdigit()
#include <string.h>	// strtok()

#pragma region Structs

// Represents a single cell on the game board.
typedef struct cell {

	Ship* ship; // pointer to the information about the ship present in this cell. NULL for empty
	int hit; // -1 for miss, 0 for not hit, 1 for hit

}Cell;

// Contains all the data related to a ship.
typedef struct ship {

	char symbol; // the symbol to display on the game board to represent this ship
	int size; // the amount of spaces this ship takes up
	const char* name; // the name of the ship

}Ship;

// Contains all the statistics for a single player.
typedef struct stats {

	int num_hits;
	int num_misses;
	int total_shots;
	double hit_ratio; // number of hits / total shots
	int won; // 1 for they won, 0 for they lost

}Stats;

#pragma endregion


/*
	Entry point for the application.
*/
void start_application();

/*
	Plays a single game of battleship.
*/
void play_battleship();

/*
	Prints the game rules of Battleship to the screen.
*/
void print_game_rules();

#pragma region Utility

/*
	Gets an integer from the user.

	@return the value entered in stdin
*/
int get_int();

/*
	Gets an character from the user.

	@return the value entered in stdin
*/
char get_char();

#pragma endregion


#endif
